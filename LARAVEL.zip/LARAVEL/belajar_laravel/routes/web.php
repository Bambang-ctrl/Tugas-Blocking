<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\BookController;

Route::get('/', [PageController::class, 'index']);
Route::get('/about', [PageController::class, 'about']);
Route::get('/siswa', [PageController::class, 'siswa']);

Route::get('/welcome', function () {
    return view('welcome');
});

Route::resource('books', BookController::class);
