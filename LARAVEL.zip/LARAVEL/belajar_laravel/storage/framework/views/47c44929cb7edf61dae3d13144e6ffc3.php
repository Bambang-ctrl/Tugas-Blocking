<h1>Selamat Datang di Laravel</h1>
<p>Belajar Framework bersama Bloking PPLG.</p>
<?php /**PATH C:\Users\LENOVO\Downloads\Belajar_laravel\LARAVEL\belajar_laravel\resources\views/home.blade.php ENDPATH**/ ?>