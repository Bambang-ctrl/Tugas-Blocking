<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Belajar Laravel'); ?></title>
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: Arial, sans-serif; background: #f3f4f6; color: #1f2937; }
        nav { background: #1d4ed8; padding: 15px 30px; }
        nav a { color: white; text-decoration: none; margin-right: 20px; font-weight: bold; }
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        h1, h2 { margin-top: 0; }
        .card, form, table { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,.08); }
        form { padding: 24px; }
        label { display: block; margin-bottom: 6px; font-weight: bold; }
        input { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 5px; margin-bottom: 15px; }
        button, .btn { display: inline-block; border: 0; padding: 10px 16px; border-radius: 5px; text-decoration: none; cursor: pointer; color: white; background: #1d4ed8; }
        .btn-warning { background: #d97706; }
        .btn-danger { background: #dc2626; }
        .btn-secondary { background: #6b7280; }
        table { width: 100%; border-collapse: collapse; overflow: hidden; }
        th, td { padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: left; }
        th { background: #f3f4f6; }
        .actions { white-space: nowrap; }
        .mb-4 { margin-bottom: 16px; }
        .flex { display: flex; gap: 10px; align-items: center; }
        .justify-between { justify-content: space-between; }
        .text-center { text-align: center; }
        ul { background: white; padding: 20px 40px; border-radius: 8px; }
    </style>
</head>
<body>
    <nav>
        <a href="<?php echo e(url('/')); ?>">Home</a>
        <a href="<?php echo e(url('/about')); ?>">About</a>
        <a href="<?php echo e(url('/siswa')); ?>">Siswa</a>
        <a href="<?php echo e(url('/books')); ?>">Buku</a>
    </nav>

    <main class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\Users\LENOVO\Downloads\Belajar_laravel\LARAVEL\belajar_laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>