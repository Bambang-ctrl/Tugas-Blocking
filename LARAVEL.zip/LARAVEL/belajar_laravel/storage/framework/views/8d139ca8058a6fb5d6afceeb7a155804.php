<?php $__env->startSection('title', 'Tambah Buku'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">Tambah Buku Baru</h2>

<form action="/books/add" method="POST" >
    <?php echo csrf_field(); ?>
    <div>
        <label >Judul Buku</label>
        <input type="text" name="title" placeholder="Judul Buku"  required>
    </div>
    <div>
        <label >Penulis</label>
        <input type="text" name="author" placeholder="Penulis"  required>
    </div>
    <div>
        <label >Penerbit</label>
        <input type="text" name="publisher" placeholder="Penerbit" >
    </div>
    <div>
        <label >Tahun Terbit</label>
        <input type="number" name="year" placeholder="Tahun Terbit" >
    </div>
    <div class="flex">
        <button type="submit" class="btn">Simpan</button>
        <a href="/books" class="btn btn-secondary">Batal</a>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\Downloads\Belajar_laravel\LARAVEL\belajar_laravel\resources\views/add-book.blade.php ENDPATH**/ ?>