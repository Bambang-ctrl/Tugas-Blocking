<?php $__env->startSection('title', 'Daftar Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between mb-4">
    <h2 class="text-2xl font-bold">Daftar Buku Perpustakaan</h2>
    <a href="/books/add" class="btn">+ Tambah Buku</a>
</div>

<table >
    <thead >
        <tr>
            <th >No</th>
            <th >Judul</th>
            <th >Penulis</th>
            <th >Penerbit</th>
            <th >Tahun</th>
            <th class="p-3 text-center">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="border-b hover:bg-gray-50">
            <td ><?php echo e($index + 1); ?></td>
            <td ><?php echo e($book->title); ?></td>
            <td ><?php echo e($book->author); ?></td>
            <td ><?php echo e($book->publisher ?? '-'); ?></td>
            <td ><?php echo e($book->year ?? '-'); ?></td>
            <td class="actions text-center">
                <a href="/books/edit/<?php echo e($book->id); ?>" class="btn btn-warning">Edit</a>
                <a href="/books/delete/<?php echo e($book->id); ?>" onclick="return confirm('Yakin ingin menghapus?')" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\Downloads\Belajar_laravel\LARAVEL\belajar_laravel\resources\views/books.blade.php ENDPATH**/ ?>