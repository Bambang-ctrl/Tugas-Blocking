<?php $__env->startSection('title', 'Daftar Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between mb-4">
    <h2>Daftar Buku Perpustakaan</h2>
    <a href="<?php echo e(route('books.create')); ?>" class="btn">+ Tambah Buku</a>
</div>

<table>
    <thead><tr><th>No</th><th>Judul</th><th>Penulis</th><th>Penerbit</th><th>Tahun</th><th>Aksi</th></tr></thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($index + 1); ?></td><td><?php echo e($book->title); ?></td><td><?php echo e($book->author); ?></td>
            <td><?php echo e($book->publisher ?? '-'); ?></td><td><?php echo e($book->year ?? '-'); ?></td>
            <td class="actions">
                <a href="<?php echo e(route('books.edit', $book)); ?>" class="btn btn-warning">Edit</a>
                <form action="<?php echo e(route('books.destroy', $book)); ?>" method="POST" style="display:inline; padding:0; box-shadow:none;" onsubmit="return confirm('Yakin ingin menghapus buku ini?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6" class="text-center">Belum ada data buku.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\LENOVO\Downloads\Belajar_laravel3\Belajar_laravel\LARAVEL\belajar_laravel\resources\views/books/index.blade.php ENDPATH**/ ?>