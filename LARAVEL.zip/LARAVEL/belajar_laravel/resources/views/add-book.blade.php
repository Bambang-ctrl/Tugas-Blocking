@extends('layouts.app')

@section('title', 'Tambah Buku')

@section('content')
<h2 class="mb-4">Tambah Buku Baru</h2>

<form action="/books/add" method="POST" >
    @csrf
    <div>
        <label >Judul Buku</label>
        <input type="text" name="title" placeholder="Judul Buku"  required>
    </div>
    <div>
        <label >Penulis</label>
        <input type="text" name="author" placeholder="Penulis"  required>
    </div>
    <div>
        <label >Penerbit</label>
        <input type="text" name="publisher" placeholder="Penerbit" >
    </div>
    <div>
        <label >Tahun Terbit</label>
        <input type="number" name="year" placeholder="Tahun Terbit" >
    </div>
    <div class="flex">
        <button type="submit" class="btn">Simpan</button>
        <a href="/books" class="btn btn-secondary">Batal</a>
    </div>
</form>
@endsection