@extends('layouts.app')

@section('title', 'Edit Buku')

@section('content')
<h2 class="mb-4">Edit Data Buku</h2>

<form action="/books/edit/{{ $book->id }}" method="POST" >
    @csrf
    <div>
        <label >Judul Buku</label>
        <input type="text" name="title" value="{{ $book->title }}"  required>
    </div>
    <div>
        <label >Penulis</label>
        <input type="text" name="author" value="{{ $book->author }}"  required>
    </div>
    <div>
        <label >Penerbit</label>
        <input type="text" name="publisher" value="{{ $book->publisher }}" >
    </div>
    <div>
        <label >Tahun Terbit</label>
        <input type="number" name="year" value="{{ $book->year }}" >
    </div>
    <div class="flex">
        <button type="submit" class="btn">Perbarui</button>
        <a href="/books" class="btn btn-secondary">Batal</a>
    </div>
</form>
@endsection