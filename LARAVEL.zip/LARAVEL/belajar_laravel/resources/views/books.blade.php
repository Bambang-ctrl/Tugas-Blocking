@extends('layouts.app')

@section('title', 'Daftar Buku')

@section('content')
<div class="flex justify-between mb-4">
    <h2 class="text-2xl font-bold">Daftar Buku Perpustakaan</h2>
    <a href="/books/add" class="btn">+ Tambah Buku</a>
</div>

<table >
    <thead >
        <tr>
            <th >No</th>
            <th >Judul</th>
            <th >Penulis</th>
            <th >Penerbit</th>
            <th >Tahun</th>
            <th class="p-3 text-center">Aksi</th>
        </tr>
    </thead>
    <tbody>
        @foreach($books as $index => $book)
        <tr class="border-b hover:bg-gray-50">
            <td >{{ $index + 1 }}</td>
            <td >{{ $book->title }}</td>
            <td >{{ $book->author }}</td>
            <td >{{ $book->publisher ?? '-' }}</td>
            <td >{{ $book->year ?? '-' }}</td>
            <td class="actions text-center">
                <a href="/books/edit/{{ $book->id }}" class="btn btn-warning">Edit</a>
                <a href="/books/delete/{{ $book->id }}" onclick="return confirm('Yakin ingin menghapus?')" class="btn btn-danger">Hapus</a>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection