@extends('layouts.app')

@section('title', 'Daftar Buku')

@section('content')
<div class="flex justify-between mb-4">
    <h2>Daftar Buku Perpustakaan</h2>
    <a href="{{ route('books.create') }}" class="btn">+ Tambah Buku</a>
</div>

<table>
    <thead><tr><th>No</th><th>Judul</th><th>Penulis</th><th>Penerbit</th><th>Tahun</th><th>Aksi</th></tr></thead>
    <tbody>
    @forelse ($books as $index => $book)
        <tr>
            <td>{{ $index + 1 }}</td><td>{{ $book->title }}</td><td>{{ $book->author }}</td>
            <td>{{ $book->publisher ?? '-' }}</td><td>{{ $book->year ?? '-' }}</td>
            <td class="actions">
                <a href="{{ route('books.edit', $book) }}" class="btn btn-warning">Edit</a>
                <form action="{{ route('books.destroy', $book) }}" method="POST" style="display:inline; padding:0; box-shadow:none;" onsubmit="return confirm('Yakin ingin menghapus buku ini?')">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
    @empty
        <tr><td colspan="6" class="text-center">Belum ada data buku.</td></tr>
    @endforelse
    </tbody>
</table>
@endsection
