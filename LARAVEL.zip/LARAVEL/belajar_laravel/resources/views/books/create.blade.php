@extends('layouts.app')
@section('title', 'Tambah Buku')
@section('content')
<h2 class="mb-4">Tambah Buku Baru</h2>
<form action="{{ route('books.store') }}" method="POST">
    @csrf
    <label for="title">Judul Buku</label>
    <input id="title" name="title" value="{{ old('title') }}" required maxlength="255">
    <label for="author">Penulis</label>
    <input id="author" name="author" value="{{ old('author') }}" required maxlength="255">
    <label for="publisher">Penerbit</label>
    <input id="publisher" name="publisher" value="{{ old('publisher') }}" maxlength="255">
    <label for="year">Tahun Terbit</label>
    <input id="year" type="number" name="year" value="{{ old('year') }}" min="1000" max="{{ date('Y') + 1 }}">
    <div class="flex"><button type="submit">Simpan</button><a href="{{ route('books.index') }}" class="btn btn-secondary">Batal</a></div>
</form>
@endsection
