<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Belajar Laravel')</title>
    <style>
        * { box-sizing: border-box; }
        body { margin: 0; font-family: Arial, sans-serif; background: #f3f4f6; color: #1f2937; }
        nav { background: #1d4ed8; padding: 15px 30px; }
        nav a { color: white; text-decoration: none; margin-right: 20px; font-weight: bold; }
        .container { max-width: 1000px; margin: 30px auto; padding: 0 20px; }
        h1, h2 { margin-top: 0; }
        .card, form, table { background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,.08); }
        form { padding: 24px; }
        label { display: block; margin-bottom: 6px; font-weight: bold; }
        input { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 5px; margin-bottom: 15px; }
        button, .btn { display: inline-block; border: 0; padding: 10px 16px; border-radius: 5px; text-decoration: none; cursor: pointer; color: white; background: #1d4ed8; }
        .btn-warning { background: #d97706; }
        .btn-danger { background: #dc2626; }
        .btn-secondary { background: #6b7280; }
        table { width: 100%; border-collapse: collapse; overflow: hidden; }
        th, td { padding: 12px; border-bottom: 1px solid #e5e7eb; text-align: left; }
        th { background: #f3f4f6; }
        .actions { white-space: nowrap; }
        .mb-4 { margin-bottom: 16px; }
        .flex { display: flex; gap: 10px; align-items: center; }
        .justify-between { justify-content: space-between; }
        .text-center { text-align: center; }
        ul { background: white; padding: 20px 40px; border-radius: 8px; }
    </style>
</head>
<body>
    <nav>
        <a href="{{ url('/') }}">Home</a>
        <a href="{{ url('/about') }}">About</a>
        <a href="{{ url('/siswa') }}">Siswa</a>
        <a href="{{ route('books.index') }}">Buku</a>
    </nav>

    <main class="container">
        @if (session('success'))
            <div class="card" style="padding:12px 16px; margin-bottom:16px; color:#166534;">{{ session('success') }}</div>
        @endif
        @if ($errors->any())
            <div class="card" style="padding:12px 16px; margin-bottom:16px; color:#b91c1c;">
                <strong>Periksa kembali input:</strong>
                <ul style="margin-bottom:0;">@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
            </div>
        @endif
        @yield('content')
    </main>
</body>
</html>
