# Belajar Laravel - Versi Diperbaiki

Proyek ini sudah diperbaiki pada controller, route, view, dan layout.

## Perbaikan utama
- `Pagecontroller.php` diganti menjadi `PageController.php` agar sesuai dengan pemanggilan controller Laravel.
- Ditambahkan method `siswa()` pada `PageController`.
- Route edit buku diperbaiki dari view `edit-book` menjadi `edit-buku`.
- Ditambahkan `resources/views/layouts/app.blade.php` yang dibutuhkan oleh halaman buku.
- Halaman Home diperbaiki penulisan HTML-nya.
- Tampilan halaman buku dibuat tetap bisa digunakan tanpa harus menjalankan Vite/Tailwind terlebih dahulu.

## Cara menjalankan
1. Ekstrak folder proyek.
2. Buka terminal pada folder `belajar_laravel`.
3. Pastikan PHP memiliki ekstensi `mbstring` dan `pdo_sqlite`/`sqlite3` aktif.
4. Jalankan:

```bash
php artisan serve
```

5. Buka `http://127.0.0.1:8000`.

## Halaman yang tersedia
- `/` Home
- `/about` About
- `/siswa` Daftar siswa
- `/books` Daftar buku
- `/books/add` Tambah buku
- `/books/edit/{id}` Edit buku
- `/books/delete/{id}` Hapus buku

Database SQLite sudah tersedia di `database/database.sqlite`.
