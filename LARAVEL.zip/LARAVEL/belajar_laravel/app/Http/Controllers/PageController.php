<?php

namespace App\Http\Controllers;

class PageController extends Controller
{
    public function index()
    {
        return view('home');
    }

    public function about()
    {
        $nama = 'Ilham';
        $mapel = 'Bloking';

        return view('about', compact('nama', 'mapel'));
    }

    public function siswa()
    {
        $siswa = [
            'Andi',
            'Budi',
            'Citra',
            'Dimas',
            'Eka',
        ];

        return view('siswa', compact('siswa'));
    }
}
